# practica02-2bim

## Uso de pandas para limpieza de datos
