"""
    @reroes
    # Decoradores
"""

def decorador(f):
    def la_funcion(*args, **kwargs): # convención
        print(args)
        for i, arg in enumerate(args[0]):
            print("argumento %d : valor %s" % (i, arg))
        return f(*args, **kwargs)
    return la_funcion 

@decorador
def sumar_lista(lista):
    return sum(lista)

def concatenar_cadena(lista):
	cadena = ""
	for c in lista:
		cadena = "%s%s\n" % (cadena, c)
	return cadena


def sumar_listaDos(lista):
    return sum(lista)

print(sumar_lista([10, 20, 30]))
# print("---")
# print(sumar_listaDos([10, 20, 30]))
print(concatenar_cadena(["10", "20", "30"]))
