"""
    @ricardoifc
    # Decoradores
"""
def decorador(f):
    def la_funcion(*args, **kwargs):
        print("Ejecutando %s:" % (f.__name__))
        return f(*args, **kwargs)
    return la_funcion 

@decorador
def suma(a, b):
	return a+b

@decorador
def resta(a,b):
	return a-b

@decorador
def multiplicacion(a, b):
	return a*b

@decorador
def potencia(a, b):
	return a**b

print(suma(10, 20))
print(resta(20, 5))
print(multiplicacion(2, 20))
print(potencia(4, 5))