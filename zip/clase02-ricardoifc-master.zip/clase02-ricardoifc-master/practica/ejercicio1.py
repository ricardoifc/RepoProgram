"""
	Ejercicio 1
	@ricardoifc
"""
#con lambda se aplica una funcion despues de x: ... y x siendo (2)
valor_par = lambda x: x%2 == 0

print(valor_par(2))
print(valor_par(3))
print(valor_par(11))
