"""
	Ejercicio 3
	@ricardoifc
"""
#sumo x1 y x2 despues de los 2 puntos
suma = lambda x1, x2: x1 + x2
print(suma(10, 11))