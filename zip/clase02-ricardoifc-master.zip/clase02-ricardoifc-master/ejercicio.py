"""
	Ejemplo 1: uso de funcion lambda
	@ricardoifc
"""
lista = [10, 2, 3, 5]

mifuncion = lambda x: x[2]
print(mifuncion(lista))