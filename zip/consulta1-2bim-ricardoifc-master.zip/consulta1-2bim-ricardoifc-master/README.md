# consulta1-2bim

## Uso del comando Yield en python.

### Realizar al menos 3 ejemplos explicativos

#### Ubicar la bibliografía consultada
