"""
    @reroes
    Tomando de: Processing collections via recursion
                Recursions
                Functional Python Programming - 2015
    use a higher-order function which returns a generator expression
"""

def funcion2(x):
    return x**2

def mapf(funcion2, lista):
    return (funcion2(x) for x in lista)


print(mapf(funcion2, [2,4,5]))
print(list(mapf(funcion2, [2,4,5])))

