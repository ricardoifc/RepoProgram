"""
    @reroes
    Tomando de: Processing collections via recursion
                Functional Python Programming - 2015
    Uso de yield
"""

# forma tradicional
# con efectos secundarios
lista = [] # uso una variable global auxiliar
def pares():
    for i in range(1,10):
        lista.append(i*2)
pares()
print(lista)


print("Usando yield")
# haciendo uso de yield como generador
# que permite retornar el valor de una 
# secuencia pero paso a paso

def pares():
    for i in range(1,10):
        yield i*2

print(pares()) # imprimo un generador
print(list(pares())) # imprimo un generador
