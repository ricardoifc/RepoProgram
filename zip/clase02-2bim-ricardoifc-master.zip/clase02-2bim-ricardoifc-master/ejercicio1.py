"""
    @reroes
    Tomando de: Processing collections via recursion
                Recursions
                "When working with a collection, we can also define the 
                processing recursively."
                Functional Python Programming - 2015
    Algorimto recursivo para el manejo de la función map
"""

def funcion2(x):
    return x**2

def mapr(f, collection):
    if len(collection) == 0:
        return []
    return mapr(f, collection[:-1])+[f(collection[-1])]

print(mapr(funcion2, [2,4,5]))
print(mapr(lambda x: x+10, [2,-1,4,-5]))
print(mapr(funcion2, mapr(lambda x: x+10, [2,-1,4,-5])))
print(mapr(lambda x: x[0], ["loja", "azuay", "pichincha", "guayas"]))
print(mapr(lambda x: x[0], ["loja", "azuay", "pichincha", "guayas"]))
