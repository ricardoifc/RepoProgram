"""
    @reroes
    Tomando de: Processing collections via recursion
                Recursions
                Functional Python Programming - 2015
    use a higher-order function which returns a generator expression
"""

def funcion2(x):
    return x**2

def mapg(f, C):
    for x in C:
        yield f(x)

print(mapg(funcion2, [2,4,5]))
print(list(mapg(funcion2, [2,4,5])))

