"""
    @reroes
    Programación Funcional: 
        Funciones Puras
        Efectos Secundarios
"""


def multiplicacion(n):
    """
        return n**2
    """

    return 1+n**2


print(multiplicacion(10))
