# clase06
