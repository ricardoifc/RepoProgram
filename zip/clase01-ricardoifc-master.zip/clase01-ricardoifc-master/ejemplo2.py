valores = [10, 2, 11, 12, 15]

resultado = list(filter(lambda x: x%2==0, valores))

print(resultado)