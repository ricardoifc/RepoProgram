"""
	@ricardoifc
"""

dato = [1, 2, 10, 11, 12, 13]

resultado = []

for i in datos:
	if i%2 ==0:
		resultado.append(i)

print(resultado)