import rx
from rx import operators as ops

source = rx.of("Alpha", "Beta", "Gamma", "Delta", "Epsilon")

composed = source.pipe(
    ops.map(lambda s: (s, len(s))),
    ops.filter(lambda i: i[1] == 4)
)
composed.subscribe(lambda value: print(" {0}".format(value)))
