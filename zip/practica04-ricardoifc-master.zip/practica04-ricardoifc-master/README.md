# practica04
## En función del archivo .txt, hacer:
- Encontrar todos los que han hecho mas de 3 goles
- Encontrar los que son del país Nigeria
- El valor mínimo y máximo de la caracteristica Height
