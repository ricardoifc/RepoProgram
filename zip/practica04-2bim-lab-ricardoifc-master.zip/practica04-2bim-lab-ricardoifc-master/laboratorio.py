"""
    @Ricardoifc
    - Laboratorio
"""
# importar las librerias
import pandas as pd 
import datetime

# leer el archivo csv
data = pd.read_csv("data21.csv", sep=",")
# print (data)
# print(data.keys()) 

# el decorador donde obtenemos el registro log
def decorador(f):
	def la_funcion(*args, **kwargs):
		fecha = datetime.datetime.now() # ovtencion de la fecha actual
		# abrir el archivo creado
		archivo = open("log.csv", "a")
		archivo.write("date %s;transacción Tranformando información  %s;"\
			" metodo usado %s\n" % (fecha , args[0], f.__name__))
		archivo.close()
		return f(*args, **kwargs)
	return la_funcion 

# le agregamos el decorador 
# obtencion de el numero entero de el mes
@decorador
def mes_to_int(mes):
	mesNum = 0
	if mes == "Enero":
		mesNum = 1
	if mes == "Febrero":
		mesNum = 2
	if mes == "Marzo":
		mesNum = 3
	if mes == "Abril":
		mesNum = 4
	if mes == "Mayo":
		mesNum = 5
	if mes == "Junio":
		mesNum = 6
	if mes == "Julio":
		mesNum = 7
	if mes == "Agosto":
		mesNum = 8
	if mes == "Septiembre":
		mesNum = 9
	if mes == "Octubre":
		mesNum = 10
	if mes == "Noviembre":
		mesNum = 11
	if mes == "Diciembre":
		mesNum = 12
	return mesNum,

# obtencion rango de edad
@decorador
def rango_edades(edad):
	edadRango = 0
	if (edad >= 0) and (edad <=20):
		edadRango = "edad1"
	if (edad > 20) and (edad <= 30):
		edadRango = "edad2"
	if (edad > 30) and (edad <= 50):
		edadRango = "edad3"
	if (edad >= 50):
		edadRango = "edad4"
	return edadRango

# agrega una nueva columna y envia mes_0c a la funcion
data['mesInt'] = data['mes_0c'].apply(mes_to_int)

data['rangoFechas'] = data['edad_mad'].apply(rango_edades)

