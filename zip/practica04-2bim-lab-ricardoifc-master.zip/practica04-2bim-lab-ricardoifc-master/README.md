# laboratorio01-2bim
### Se puede usar un notebook de jupyter o generar un archivo .py para la solución
