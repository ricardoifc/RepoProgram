"""
    @reroes
    - uso de reduce
    -  uso de groupby
"""
from functools import reduce
from itertools import *
import pandas as pd

data = pd.read_csv("data02.csv", sep=";")
data_record = data.to_dict("records")
data_record = sorted(data_record, key=lambda x:list(x.items()))
# print(data_record)

# lista del groupby
lista = list(map(lambda x: [x[0], list(x[1])], 
    groupby(data_record, lambda x: x['Provincia'])))

print("quintales de arroz")
# en la posicion 0 primer map tengo la provincia y por cada provincia 
# hago un sum de un map en la posicion 3 = es la posicion arroz y 1 = el valor
# de el map le envio la posicion 1 que es la lista y el primer map le envio 
# la lista
print(list(map(lambda x:[x[0], sum(map(lambda x: list(x.items())[3][1], 
    x[1]))] ,lista)))
