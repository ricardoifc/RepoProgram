# practica06-leccion
