"""
	@ricardoifc
	Problema5
"""

edad = [10, 12, 13, 14, 16, 18, 20, 30, 31, 32, 33, 40, 50]

black_edad = [10, 14, 30, 32, 40, 16]
print()
#hacermos la coparacion 
def comparacion(x):
	black_edad
	if x in black_edad:
		return false
	else:
		return false
#envio datos al def
resultado = filter(comparacion_edades, edades)
#imrpimo datos
print(list(resultado))