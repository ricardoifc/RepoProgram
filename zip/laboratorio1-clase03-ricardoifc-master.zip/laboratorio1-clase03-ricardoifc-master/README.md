# laboratorio1
### Realizar los ejercicios planteados en el archivo laboratorio1.txt
